#!/bin/bash

python3 -m pip install "numpy>=1.19.2"
python3 -m pip install "matplotlib>=3.3.1"
python3 -m pip install "pandas>=1.1.2"
python3 -m pip install "seaborn>=0.11.0"
python3 -m pip install "scipy>=1.5.1"
